import pandas as pd
dataframe=pd.read_excel('../Dataset/SalesTransactions.xlsx')

print(dataframe)